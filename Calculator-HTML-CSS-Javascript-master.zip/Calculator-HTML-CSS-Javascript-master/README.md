# Calculator HTML/CSS/Javascript

This is simple calculator web application based on Html/CSS/Javascript. I refered the exemple of [thecodeplayer](http://thecodeplayer.com/walkthrough/javascript-css3-calculator) but changed Jquery to Javascript.

I made this simple web application aiming to learn front-end technologie.

## Screenshots

![screen-shot](https://github.com/DONGChuan/Calculator-HTML-CSS-Javascript/blob/master/images/screenshot.png)
