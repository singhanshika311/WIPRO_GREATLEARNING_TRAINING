# Simple-Calculator
Simple Calculator using HTML, CSS &amp; Javascript.

|Sumit| Webisite|
|-----| -------- |
|**My Personal Website**| [**Visit**](https://sumitnce1.github.io)
|**My Portfolio 1**| [**Visit**](http://sumitnce.ml)
|**My Simple Calci**| [**Visit**](https://sumitnce1.github.io/Simple-Calculator/)

<img src="cal.png" width="100%">

# Coding Site
|Sumit| Webisite|
|-----| -------- |
|**GitHub**| [**Visit**](https://github.com/sumitnce1)
|**GeeksForGeeks**| [**Visit**](https://auth.geeksforgeeks.org/user/sumitnce1/)
|**HackerRank**| [**Visit**](https://www.hackerrank.com/sumitnce1)
|**HackerEarth**| [**Visit**](https://www.hackerearth.com/@sumit1641)
|**CodeChef**| [**Visit**](https://www.codechef.com/users/sumitnce1)


# Contact Social
|Sumit| Webisite|
|-----| -------- |
|**LinkDin**| [**Visit**](https://www.linkedin.com/in/sumitnce1/)
|**My Twitter**| [**Visit**](https://twitter.com/Sumitnce1)
|**My facbook Page**| [**Visit**](https://www.facebook.com/sumitnce1/)
|**My Instagram**| [**Visit**](https://www.instagram.com/s.sumitsingh1111/)
|**YouTube**| [**Visit**](https://www.youtube.com/channel/UC9O21h7f1h98JxyzMLfj1bg?view_as=subscriber)

# **Thank You!**

