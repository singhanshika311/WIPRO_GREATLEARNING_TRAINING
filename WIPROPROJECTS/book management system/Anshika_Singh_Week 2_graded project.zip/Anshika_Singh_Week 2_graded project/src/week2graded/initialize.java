package week2graded;
//class containing recursive menu logic to display the calue once user input numeric oprion 
/** 
* <h2> Creating a Class initialize which implements Runnable interface  </h2> 
* This program implements an application 
* to perform operation we need a to create a class name initialize which implements Runnable interface and initialize value  
* and print the result  
* <p> 
* <b>Note:</b> Comments make the code readable and  
* easy to understand. 
*  
* @author Anshika Singh
* @version 17.0 
* @since 2022-04-13 
*/

public class initialize implements Runnable {
	static MagicOfBooks magic = new MagicOfBooks();
	

	@Override
	public void run() {
		try {
			System.out.println("WELCOME IN BOOKS MANAGEMENT SYSTEM");
			System.out.println("Now you can start");
			System.out.println("Please enter your username:");

			variables.inputuser = variables.sc.nextLine();
			//if userName space is empty
			if(variables.inputuser.trim().isEmpty())
			{
				throw new InvalidInputException("you didnt entered the username"); 
			}
			boolean a = magic.checkUser();
			//if userName is present
			if (a) {
				System.out.println("Welcome " + variables.outputuser + "!");
				magic.opt();
				magic.torun();
            //if userName is not valid 
			} else {
				System.out.println("Sorry! You are not an authorized user");
			}

		}
		//if userName space is empty
		catch (Exception e) {
			System.out.println("you didnt entered the username");
		}
		catch (AbstractMethodError e) {
			System.out.println("please wait for system to reboot");
		}

	}

}
