package week2graded;
//class containing InvalidInputException to handle custom exceptions
/** 
* <h2> Creating a custom class exception handeling  </h2> 
* This program implements an application   
* <p> 
* <b>Note:</b> Comments make the code readable and  
* easy to understand. 
*  
* @author Anshika Singh
* @version 17.0 
* @since 2022-04-13 
*/
class InvalidInputException  extends Exception  
{  
    public InvalidInputException (String str)  
    {  
        // calling the constructor of parent Exception  
        super(str);  
    }
}