package week2graded;
//class containing Thread to start the application as new Thread
/** 
* This program implements thread interface
* to perform operation need the application to start everytime as a new Thread   
* and print the result  
* <p> 
* <b>Note:</b> Comments make the code readable and  
* easy to understand. 
*  
* @author Anshika Singh 
* @version 17.0 
* @since 2022-04-13 
*/

public class main {

	public static void main(String[] args) {
		try {
			initialize obj = new initialize();
			Thread thread = new Thread(obj);  //creating object of thread
			thread.start();

		} catch (Exception e) {
			System.out.println("You stopped the process abruptly please try again later");
		}catch (AbstractMethodError e) {
			System.err.println("please wait");
		}

	}

}
