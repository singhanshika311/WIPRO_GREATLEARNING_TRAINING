package week2graded;
//class containing Variables
/** 

* to perform operation we need a to create a class book and initialize value  
* and print the result  
* @author Anshika Singh
* @version 17.0 
* @since 2022-04-13 
*/

import java.util.Scanner;

public class variables {
	public static String inputuser;
	public static String inputbook;
	public static String outputuser;
	public static Scanner sc = new Scanner(System.in);
	public static String conti="yes";
}
