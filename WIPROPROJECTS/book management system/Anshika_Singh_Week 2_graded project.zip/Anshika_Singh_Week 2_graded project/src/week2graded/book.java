package week2graded;

//class containing array of bookName,authorName,description,bookId 
/** 
 * <h2> Creating a Class to initialize bookName,authorName,description,bookId  </h2> 
 * This program implements an application 
 * to perform operation we need a to create a class book and initialize value  
 * and print the result  
 * <p> 
 * <b>Note:</b> Comments make the code readable and  
 * easy to understand. 
 *  
 * @author Anshika Singh
 * @version 17.2
 * @since 2022-04-13 
 */

public class book {
	
	public String[] getBookName() {
		return bookName;
	}
	public void setBookName(String[] bookName) {
		this.bookName = bookName;
	}
	public String[] getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String[] authorName) {
		this.authorName = authorName;
	}
	public String[] getDescription() {
		return description;
	}
	public void setDescription(String[] description) {
		this.description = description;
	}
	public Integer[] getBookId() {
		return bookId;
	}
	public void setBookId(Integer[] bookId) {
		this.bookId = bookId;
	}
	String[] bookName = { "Ulysses", "Don Quixote", "One Hundred Years of Solitude", "Hamlet",
			"In Search of Lost Time" };
	String[] authorName = { "James Joyce", "Miguel de Cervantes", "Gabriel Garcia Marquez", "William Shakespeare",
			"Marcel Prous" };
	String[] description = { "Ulysses by James Joyce", "Don Quixote by Miguel de Cervantes",
			"One Hundred Years of Solitude by Gabriel Garcia Marquez", "Hamlet by William Shakespeare",
			"In Search of Lost Time by Marcel Prous" };
	Integer[] bookId = { 0, 1, 2, 3, 4};

}
 //end of class book