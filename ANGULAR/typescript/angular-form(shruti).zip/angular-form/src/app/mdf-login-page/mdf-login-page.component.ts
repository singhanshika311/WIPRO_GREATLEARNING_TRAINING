import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CustomService } from '../custom.service';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-mdf-login-page',
  templateUrl: './mdf-login-page.component.html',
  styleUrls: ['./mdf-login-page.component.css']
})
export class MdfLoginPageComponent implements OnInit {

  msg: string = "";
  loginRef = new FormGroup({
    email: new FormControl("", [Validators.required, Validators.minLength(3)]),           // it is equal to requried attribute in html page 
    password: new FormControl("", [Validators.required, Validators.pattern("[a-z,0-9]*")])
  })

  checkUser() {
    let login = this.loginRef.value;
    // let obj=new CustomService();
    // this.msg=obj.checkUserDetails(login)
    // if (login.email = "Raj@gmail.com" && login.password == "12345") {
    //   this.msg = "Successfully login";
    // }
    // else {
    //   this.msg = "Failure!Try once again";
    // }

    this.msg=this.ls.checkUserDetails(login);

    // loginRef.reset();
  }
  constructor(public ls:LoginService) { }

  ngOnInit(): void {
  }

}
