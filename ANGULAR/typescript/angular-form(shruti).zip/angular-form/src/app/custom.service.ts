export class CustomService{
    checkUserDetails(login: any):string {
        if (login.email == "raj@gmail.com" && login.password == "123") {
           return  "Success";
    
        }
        else {
          return   "Failure ";
        }
    }
}