# A simple Calculator
 A simple calculator using HTML, CSS &amp; Javascript
 ![title-pic](https://user-images.githubusercontent.com/39196039/40139639-27db8c64-596e-11e8-9537-04a5b5d07170.jpg)
 This is a simple calculator functionality achieved using Javascript. The logic is very simple with the minimum lines of code possible.
 
## Steps to execute this calculator:
- Download the entire code 
- Open up the index.html.

## Technologies used: 
- HTML
- CSS [style/Presentation]
- Javascript [Logic/Working of calculator]
