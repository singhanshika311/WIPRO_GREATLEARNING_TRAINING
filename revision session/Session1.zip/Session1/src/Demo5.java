public class Demo5 {
    public static void main(String[] args) {

        // switch (3) {
        //     case 1:
        //         System.out.println("hello");
        //         break;
        //     case 2:
        //         System.out.println("hi");
        //         break;
        //     case 3:
        //         System.out.println("Bye");
        //         break;
        // }

       switch (3) {
           case 3 / 1:
               System.out.println("hello");
               break;
           case 3 / 2:
               System.out.println("hi");
               break;
           case 6 / 3.0:
               System.out.println("Bye");
               break;
       }


    }
}
