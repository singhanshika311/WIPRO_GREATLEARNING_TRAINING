public class Demo1 {
    public static void main(String[] args) {
 //       System.out.println(3 / 2.0);

 //       System.out.println(3 % 2);
//
       int a = 2;
       int b = ++a; //b=
       int c = a++;

       System.out.println(a + " " + b + " " + c);

//         int x = 5;
//         int y = 2;
//         int z = x+x/y*x-x;
//         System.out.println(z);


    }
}
