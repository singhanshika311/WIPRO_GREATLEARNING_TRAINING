import java.util.*;

public class Demo2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String p = in.next();
        String q = in.nextLine();
        char r = in.next().charAt(0);
        System.out.println(p);
        System.out.println(q);
        System.out.println(r);

    }
}

// tazeen khan
// tazeen khan
// tazeen khan
