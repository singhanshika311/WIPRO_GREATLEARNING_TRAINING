public class DemoConst {
    public static void main(String[] args) {
        Parent ob = new Parent("great parent", 30);
        ob.display();
    }
}

class Parent {
	String name;
	int age;
	Parent(String name, int age){
		this.name = name;
		this.age = age;

	}

	void display(){
		System.out.println(name);
		System.out.println(age);
	}


}




