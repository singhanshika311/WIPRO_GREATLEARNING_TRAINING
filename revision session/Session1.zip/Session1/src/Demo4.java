public class Demo4 {
    public static void main(String[] args) {
        int[] arr = {'a', 'b', 'c', 'd'};
        for(int tmp : arr)
        	System.out.println(tmp);
    }
}
