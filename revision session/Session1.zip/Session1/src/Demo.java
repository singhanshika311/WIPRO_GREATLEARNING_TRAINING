public class Demo {
    public static void main(String[] args) {
        //int default = 1;
        //System.out.println(default);

       //  int main = 1;
        //System.out.println(main);
        String name1 = "Adam";
        System.out.println(name1);
        System.out.println("name1");



    }
}

