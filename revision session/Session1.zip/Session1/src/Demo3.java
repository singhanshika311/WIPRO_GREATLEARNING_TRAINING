import java.util.Scanner;

public class Demo3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String p = new String("hello");
        String q = new String("hello");
        String r = "hello";
        String s = "hello";
        System.out.println(p == q);
        System.out.println(q == r);
        System.out.println(r == s);

//        int x = 5;
//        int y = 10;
//        System.out.println("sum: " + x + y);

    }
}
