public class Demo7 {
    public static void main(String[] args) {

        for (int i = 1; i < 35; i++) {
            if (i % 2 == 1) {
                break;
            }
            System.out.print(i+" ");
        }

        	
    }
}
