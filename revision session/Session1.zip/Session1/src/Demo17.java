import java.util.ArrayList;

class Demo17 {
	public static void main (String[] args) {
        ArrayList al = new ArrayList();
        al.add(10);
        al.add("hello");
        System.out.println(al);
	}
}
