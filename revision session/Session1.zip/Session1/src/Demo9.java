class Test {
    int x;
    int y;

    public void set(int x, int y) {
        y = x;
        this.y = y;
    }

    void print() {
        System.out.println("x=" + x + " y=" + y);
    }
}


public class Demo9 {

    public static void main(String[] args) {
        Test object = new Test();
        object.set(5, 10);
        object.print();
    }
}
