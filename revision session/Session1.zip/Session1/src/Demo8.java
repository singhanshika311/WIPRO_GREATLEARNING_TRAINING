public class Demo8 {
    public static void main(String[] args) {
        Child ob = new Child();
    }
}

class parent {
    parent(String name) {
        System.out.println(name);
    }
}

class Child extends parent {
    Child() {
    	super("name");
        System.out.println("hello");
    }
}

//child construtor -> parent constructor(has parametrized cosnt)
/*
1. create your own default const in parent
2. call parent constructor in child by passing right parameters

*/