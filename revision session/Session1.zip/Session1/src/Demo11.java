class Main {
    public void get() {
        System.out.println("Get Main");
    }
}

class Sub extends Main {
    public void get() {
        System.out.println("Get Sub");
    }
}

public class Demo11 {
    public static void main(String[] args) {
        Main b = new Sub();
        b.get();
    }
}
