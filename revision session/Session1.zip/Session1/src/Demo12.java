interface X{
  	void print();
}
class Y{
  	public void print() {
        	System.out.println("This is Y");
  	}
}
class Z extends Y implements X{
  	public void print() {
        	System.out.println("This is Z");
  	}
}

public class Demo12 {
  	public static void main(String[] args) {
        	X x = new Z();
        	x.print();
    }
}

