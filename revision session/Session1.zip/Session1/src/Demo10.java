class Mobile {
    static int year;
    String company_name;
}

public class Demo10 {

    public static void main(String[] args) {
        Mobile m = new Mobile();
        Mobile.year = 2020;
        m.company_name = "Apple";
        Mobile x = new Mobile();
        System.out.print(x.year + " " + x.company_name);
    }
}

