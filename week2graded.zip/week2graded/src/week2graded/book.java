package week2graded;

public class book {
	String[] bookName = { "Ulysses", "Don Quixote", "One Hundred Years of Solitude", "Hamlet",
			"In Search of Lost Time" };
	String[] authorName = { "James Joyce", "Miguel de Cervantes", "Gabriel Garcia Marquez", "William Shakespeare",
			"Marcel Prous" };
	String[] description = { "Ulysses by James Joyce", "Don Quixote by Miguel de Cervantes",
			"One Hundred Years of Solitude by Gabriel Garcia Marquez", "Hamlet by William Shakespeare",
			"In Search of Lost Time by Marcel Prous" };
	Integer[] bookId = { 0, 1, 2, 3, 4};

}
