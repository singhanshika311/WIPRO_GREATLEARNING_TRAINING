// Creating a recursive menu for user



 //This program is an integration towards accessing the different options of book class
 // this program uses while loop and switch case and is connected to DAO classes
  
 // Note: Exception handeling is been added and thread has been . 
   
 // @author Ramkrishna  Dakwa (Great Learning FSD C - 10th Batch)
 //@version 17.0 
 // @since 2nd April 2022 
package com.main;

import java.util.Scanner;
import com.bean.Book;
import com.service.Bookservice;
import Exceptions.WrongInputError;
import Logger.Mylogger;


public class MagicOfBooks implements Runnable{
	@Override
	public void run() {
		Bookservice bs = new Bookservice();
		Scanner scan = new Scanner(System.in);
		int choice;
		String con1 = null;
		int con2;
		String con3;
		boolean strt=true;
		while(strt) {
			System.out.println("Please Enter Your Role(User/Admin)");
			String name = scan.nextLine();
			if (name.equalsIgnoreCase("Admin")) {
				do {
					System.out.println("************** MENU ***********\n"+"1:Add Books\n" + "2.Delete Books\n" + "3.UpdateBooks\n"
							+ "4.Display all the Books\n"  + "Enter your Choice");
					choice = Integer.parseInt(scan.nextLine());
					if(choice>=1 && choice<=4) {
						switch (choice) {
						case 1:
							Book b = bs.insertBook();
							System.out.println(bs.storeBook(b));
							System.out.println("Do you want to continue");
							con1=scan.nextLine();
							if(con1.equalsIgnoreCase("no")) {
								System.out.println("Press 1 from Main Menu and 0 For Exit!");
								int num1 = Integer.parseInt(scan.nextLine());
								if(num1==0) {
									strt=false;
									Mylogger.writeTolog("Program ends");
								}
							}
							break;
						case 2:
							System.out.println(bs.deleteBook());
							System.out.println("Do you want to continue");
							con1=scan.nextLine();
							if(!con1.equalsIgnoreCase("yes")) {
								System.out.println("Press 1 from Main Menu and 0 For Exit!");
								int num1 = Integer.parseInt(scan.nextLine());
								if(num1==0) {
									strt=false;
									Mylogger.writeTolog("Program ends");
								}
							}
							break;
						case 3:
							System.out.println(bs.UpdateBook());
							System.out.println("Do you want to continue");
							con1=scan.nextLine();
							if(con1.equalsIgnoreCase("no")) {
								System.out.println("Press 1 from Main Menu and 0 For Exit!");
								int num1 = Integer.parseInt(scan.nextLine());
								if(num1==0) {
									strt=false;
									Mylogger.writeTolog("Program ends");
								}
							}
							break;
						case 4:
//							System.out.println(bs.Displayall());
							boolean condi=true;
							int input;
							while(condi){
								System.out.println("************** MENU ***********\n"+"1:Display Book Count\n" + "2.Dislay via Genre\n" + "3.Book Information\n"
										+ "4.Arrange Books From Low to high\n"  +"5.Arrange Price from High to Low\n"+ "6.Arrange Best selling On top\n"+"Enter your Choice");
								input = Integer.parseInt(scan.nextLine());
								switch(input) {
								case 1:
									System.out.println(bs.CountBooks());
									break;
								case 2:
									bs.DisplayallbyType();
									break;
								case 3:
									System.out.println(bs.Displayall());
									break;
								case 4:
									bs.Arrange(1);
									break;
								case 5:
									bs.Arrange(2);
									break;
								case 6:
									bs.Arrange(3);
									break;
								default:
									try {
										throw new WrongInputError("Entered the Wrong Input");
									}catch (Exception e) {
										// TODO: handle exception
										System.out.println(e.getMessage());
									}
								}
								System.out.println("Do you want to continue");
								con3=scan.nextLine();
								if(con3.equalsIgnoreCase("no")) {
									System.out.println("Press 1 from Main Menu and 0 For Exit!");
									int num1 = Integer.parseInt(scan.nextLine());
									if(num1==0) {
										Mylogger.writeTolog("Program ends");
										strt=false;
										con1="no";
									}else {
										con1="yes";
									}
									condi=false;
									
								}
							}
							break;
							
							
							
							
						case 5:
							System.out.println(bs.Displayall());
							System.out.println("Do you want to continue");
							con1=scan.nextLine();
							if(con1.equalsIgnoreCase("no")) {
								System.out.println("Press 1 from Main Menu and 0 For Exit!");
								int num1 = Integer.parseInt(scan.nextLine());
								if(num1==0) {
									strt=false;
								}
							}
							break;
							
							
							
						default:
							try {
								throw new WrongInputError("Entered the Wrong Input");
							}catch (Exception e) {
								// TODO: handle exception
								System.out.println(e.getMessage());
							}

						}
					}else {
						try {
							con1="y";
							throw new WrongInputError("Entered the Wrong Input");
						}catch (Exception e) {
							Mylogger.writeTolog("Entered the wrong input");
							// TODO: handle exception
							System.out.println(e.getMessage());
						}
					}
	

				} while (con1.equalsIgnoreCase("yes"));
			}else {
				Mylogger.writeTolog("Invalid Role!.");
				System.out.println("Invalid Role!.\nPlease ReEnter\r");
			}

		}
		System.out.println("Thank You");

	}

	
}

//System.out.println("Do you want to Continue badri");
//con1=scan.nextLine();
//if(con1.equalsIgnoreCase("no")) {
//	strt=false;
//}