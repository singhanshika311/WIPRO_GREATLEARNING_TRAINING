// Creating a recursive menu for user





 //This program is an integration towards accessing the different options of book class
 // this program uses while loop and switch case and is connected to DAO classes
  
 // Note: Exception handeling is been added and thread has been . 
   
 //@author Anshika Singh (Great Learning FSD C - 7th Batch)
 //@version 17.0 
 //@since 2nd April 2022 

package com.service;

import java.util.logging.*;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.bean.Book;
import com.dao.Bookdao;

import Exceptions.UpdateException;
import Exceptions.WrongInputError;
//book service class 
import Logger.Mylogger;

public class Bookservice {
	Scanner scan = new Scanner(System.in);

	// method to take the book details from user
	public Book insertBook() {

		Book book = null;
		try {
			Mylogger.writeTolog("Adding Book");
			System.out.println("Enter the Book Id");
			int id = Integer.parseInt(scan.nextLine());
			System.out.println("Enter Bookname");
			String bname = scan.nextLine();
			if (bname.isEmpty()) {
				try {
					throw new WrongInputError("Sorry try again!");
				} catch (Exception e) {
					Mylogger.writeTolog("Adding book error ", e);
					System.out.println(e);
				}
			}
			System.out.println("Enter Book Genre");
			String genre = scan.nextLine();
			System.out.println("Enter Book Author");
			String bauthor = scan.nextLine();
			System.out.println("Enter Book description");
			String bdescription = scan.nextLine();
			System.out.println("Enter  Book Price");
			double price = Double.parseDouble(scan.nextLine());
			System.out.println("Enter number of copies sold");
			int copies = Integer.parseInt(scan.nextLine());
			book = new Book(id, bname, bauthor, price, bdescription, genre, copies);

		} catch (Exception e) {
			// TODO: handle exception
			Mylogger.writeTolog("Adding book error ", e);
			System.out.println(e.getMessage());
			System.out.println("Some Thing Went Wrong Try Again");
		}
		return book;

	}

	// method to check whether book is stored or not

	public String storeBook(Book b) {
		Bookdao bdao = new Bookdao();
		if (bdao.storeBook(b) > 0) {
			Mylogger.writeTolog("Book added sucessFully");
			return "REcord Inserted Sucessfully";
		} else {
			return "Recod dint't store";
		}
	}

	// method to check whether book of given book id ,is deleted or not
	public String deleteBook() {
		Bookdao bdao = new Bookdao();
		if (bdao.DeleteBook() > 0) {
			Mylogger.writeTolog("Book deleted SucessFully");
			return "Book Deleted!";
		} else {
			return "Record Not Deleted";
		}
	}

	// method to take the details of the book to update

	public String UpdateBook() {
		Bookdao bdao = new Bookdao();
		if (bdao.UpdateBook() > 0) {
			Mylogger.writeTolog("Book updated sucessfully");
			return "Book Updated!";
		} else {
			try {
				throw new UpdateException("Can't update the Record");

			} catch (Exception e) {
				Mylogger.writeTolog("Failed to update the book", e);
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
			return "Update UnSuccessful";
		}
	}

	// method to display all the books

	public String Displayall() {

		Bookdao bdao = new Bookdao();
		if (!bdao.RetriveBooks().isEmpty()) {
			List<Book> bookslist = bdao.RetriveBooks();
			System.out.println("=====================================================================================");
			for (Book book : bookslist) {
				System.out.println(book.getId() + " " + book.getName());
			}
			System.out.println("Please Enter the Book name id you want to Describe");
			int bkid = Integer.parseInt(scan.nextLine());
			for (Book book : bookslist) {
				if (book.getId() == bkid) {
					System.out.println("Book name :- " + book.getName());
					System.out.println("Book Genre :- " + book.getGenre());
					System.out.println("Book Author :- " + book.getAuthorname());
					System.out.println("Book description :- " + book.getDescription());
					System.out.println("Book Price :- " + book.getPrice());
					System.out.println("Book Copies sold :- " + book.getCopiesSold());
				}
			}

			System.out.println("=====================================================================================");
			Mylogger.writeTolog("Book details Displayed");
			return "Successfully retrived";
		} else {
			try {
				throw new WrongInputError("Booklist is empty");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("No Book is Available");
				return "Sorry UnSucessFul";
			}

		}
	}

	// method to count the total number of books

	public String CountBooks() {
		Bookdao bdao = new Bookdao();
		if (!bdao.RetriveBooks().isEmpty()) {
			Mylogger.writeTolog("Total number of books displayed");
			System.out.println("TOTAL BOOKS :" + bdao.RetriveBooks().size());
			return "Successfully retrived";
		} else {
			Mylogger.writeTolog("Total number of books displayed");
			System.out.println("TOTAL BOOKS :" + bdao.RetriveBooks().size());
			return "SucessFully retrived";
		}
	}

	// method to arrange in the order according to the user choice

	public void Arrange(int choice) {
		Bookdao bdao = new Bookdao();
		// int choice;
		List<Book> booklist = null;
		String con;
		String s;
		// System.out.println("1:Price - Low to High\n" + "2.Price - High to Low\n" +
		// "3.Most selling Book");
		// choice = Integer.parseInt(scan.nextLine());
		if (choice > 0 && choice <= 4) {
			switch (choice) {
			case 1:
				Mylogger.writeTolog("books order by price ascending");
				s = "from Book order by Price";
				booklist = bdao.ArrangeOrder(s);
				if (!booklist.isEmpty()) {
					System.out.println("=============================================================");
					System.out.println("Books According to price Low to High");
					for (Book book : booklist) {
						System.out.println(book.getName() + "\t price " + book.getPrice());
					}
					System.out.println("=============================================================");
				} else {
					try {
						throw new UpdateException("No Book is availabe");
					} catch (Exception e) {
						System.out.println(e.getMessage());
						// TODO: handle exception
					}
				}
				break;
			case 2:
				Mylogger.writeTolog("books order by price decending");
				s = "from Book order by Price desc";
				booklist = bdao.ArrangeOrder(s);
				if (!booklist.isEmpty()) {
					System.out.println("=============================================================");
					System.out.println("Books According to price High to Low");
					for (Book book : booklist) {
						System.out.println(book.getName() + "\t price " + book.getPrice());
					}
					System.out.println("=============================================================");
				} else {
					try {
						throw new UpdateException("No Book is availabe");
					} catch (Exception e) {
						System.out.println(e.getMessage());
						// TODO: handle exception
					}
				}

				break;
			case 3:
				Mylogger.writeTolog("Best selling books ");
				s = "from Book order by CopiesSold desc";
				booklist = bdao.ArrangeOrder(s);
				if (!booklist.isEmpty()) {
					System.out.println("=============================================================");
					System.out.println("Best selling Books");
					for (Book book : booklist) {
						System.out.println(book.getName() + "\t CopiesSold " + book.getCopiesSold());
					}
					System.out.println("=============================================================");
				} else {
					try {
						throw new UpdateException("No Book is availabe");
					} catch (Exception e) {
						System.out.println(e.getMessage());
						// TODO: handle exception
					}
				}

				break;

			default:
				System.out.println("Wrong Input");
			}
		} else {
			try {
				throw new WrongInputError("wrong Input Error");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
		}

	}

	// method to display the books related to autobiography

	public String DisplayallbyType() {
		Bookdao bdao = new Bookdao();
		boolean check = false;
		if (!bdao.RetriveBooks().isEmpty()) {
			System.out.println("Please Enter the book Genre");
			String bookname = scan.nextLine();
			List<Book> bookslist = bdao.RetriveBooks();
			for (Book book : bookslist) {
				if (book.getGenre().equalsIgnoreCase(bookname)) {
					check = true;
					break;
				}
			}
			System.out.println("=====================================================================================");
			if (check) {
				Mylogger.writeTolog("Display the Books by Genre type");
				for (Book book : bookslist) {
					if (book.getGenre().equalsIgnoreCase(bookname)) {
						System.out.println(book.getId()+"\t"+book.getName());
		
					}
				}

			} else {
				try {
					throw new UpdateException("No Book Found With " + bookname + " genre");
				} catch (Exception e) {
					// TODO: handle exception
					Mylogger.writeTolog("No Book Found with the Genre ",e);
					System.out.println(e.getMessage());
				}
			}
			System.out.println("=====================================================================================");

			return "Successfully retrived";
		} else {
			try {
				throw new UpdateException("No Book is availabe");
			} catch (Exception e) {
				Mylogger.writeTolog("No book is available",e);
				System.out.println(e.getMessage());
				// TODO: handle exception
			}
			return "Sorry UnSucessFul";
		}
	}

}
