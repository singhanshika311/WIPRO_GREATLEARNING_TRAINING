// Creating a recursive menu for user



 //This program is an integration towards accessing the different options of book class
 // this program uses while loop and switch case and is connected to DAO classes
  
 // Note: Exception handeling is been added and thread has been . 
   
 //@author Anshika Singh (Great Learning FSD C - 7th Batch)
 //@version 17.0 
 //@since 2nd April 2022 
package com.thread;

import com.main.Demotest;
import com.main.MagicOfBooks;
import com.main.BookAPIThread;

public class MainThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MagicOfBooks t = new MagicOfBooks();
		Thread thread = new Thread(t);
		thread.start();

	}

}
/*id|CopiesSold|Price |authorname         |description                                                                                                                                                                                                                                        |genre        |name                         |
--+----------+------+-------------------+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------+-----------------------------+
 1|        18| 890.0|James Joyce        |Ulysses is the story of a day in the life of Leopold Bloom as he travels Dublin and goes about his business, attending a funeral, buying soap, going to the Library, walking by the beach                                                          |Fiction      |Ulysses                      |
 2|        25|1250.0|Miguel De          |Honest, dignified, proud, and idealistic, he wants to save the world. As intelligent as he is mad, Don Quixote starts out as an absurd and isolated figure and ends up as a pitiable and lovable old man                                           |Novel        |Don Quixote                  |
 3|        23| 980.0|Gabriel G          |Widely acknowledged as Gabriel García Márquez's finest work, One Hundred Years of Solitude tells the story of the fictional Colombian town Macondo and the rise and fall of its founders, the Buendía family.                                      |Autobiography|One Hundred Years of Solitude|
 4|        26| 500.0|William Shakespeare|Hamlet is a story of how the ghost of a murdered king comes to haunt the living with tragic consequences. A vengeful ghost and a brother's murder, dominate the gloomy landscape of Hamlet's Denmark.                                              |Tragedy      |Hamlet                       |
 5|        30|1270.0|Marcel Proust      |In Search of Lost Time follows the narrator's recollections of childhood and experiences into adulthood in the late 19th-century and early 20th-century high-society France, while reflecting on the loss of time and lack of meaning in the world.|Autobiography|In Search of Lost Time       |
 6|        22|1200.0|:- Markus Zusak    |The Book Thief is a story narrated by a compassionate Death who tells us about Liesel, a girl growing up in Germany during World War II.                                                                                                           |Fiction      |The Book Thief               |*/
