use week4;
desc magicbooks;
select *from magicbooks;
